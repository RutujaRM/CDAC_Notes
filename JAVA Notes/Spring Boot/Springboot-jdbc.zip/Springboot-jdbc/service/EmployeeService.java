package com.met.cdac.iit.springbootdemo.service;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.met.cdac.iit.springbootdemo.dao.EmployeeDAO;
import com.met.cdac.iit.springbootdemo.model.Employee;

//@Component
@Service
//@Transactional
public class EmployeeService {

	//private EmployeeDAO employeeDAO = new EmployeeDAO();
	
	@Autowired
	private EmployeeDAO employeeDAO;
	
	//declarative Transaction management
	
	@Transactional(rollbackFor = Exception.class,
				timeout = 30, propagation = Propagation.REQUIRED)
	
	//, transactionManager = "hibernateTransactionManager", readOnly=false
	
	
	public void saveEmployee(Employee employee) {
		
		//perfom data validation
		//if success send call to DAO layer
		
		if(employee.getId() <= 0) {
			throw new RuntimeException("Id cannot be <= 0");
		}
		
		employeeDAO.saveEmployee(employee);
		
	}
	
	public Collection<Employee> getEmployeeList(){
		return employeeDAO.getEmployeeList();
	}
	
	@Transactional(readOnly = true)
	public Employee getEmployee(int id) {
		
		return employeeDAO.getEmployee(id);
		
	}
}
