package com.met.cdac.iit.springbootdemo.dao;

import java.util.Collection;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.met.cdac.iit.springbootdemo.model.Employee;

//@Component
@Repository
public class EmployeeDAO {

	@Autowired
	//@Qualifier("oracleDataSource")				//primary =true
	private DataSource oracleDataSource;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
					
	public void saveEmployee(Employee employee) {
		
		saveUsingJdbcTemplate(employee);
		
	}

	public void saveUsingJdbcTemplate(Employee employee) {
		
		jdbcTemplate.update("insert into employeetbl values(?,?,?,?)", 
				new Object[] {employee.getId(), employee.getName(),
						employee.getDesignation(), employee.getEmailId()}
				);
		
	}
	
	public Collection<Employee> getEmployeeList(){
		
		return jdbcTemplate.query("select * from employeetbl",
				new BeanPropertyRowMapper<Employee>(Employee.class));
		
		//jdbcTemplate.queryForObject(null, null)
	}
	
	public Employee getEmployee(int id) {
		
		return jdbcTemplate.queryForObject("select * from employeetbl"
				+ " where id=?", new Object[] {id},
				new BeanPropertyRowMapper<Employee>(Employee.class));
	
		
	}
	
}
