package com.met.cdac.iit.springbootdemo.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.met.cdac.iit.springbootdemo.model.Employee;
import com.met.cdac.iit.springbootdemo.service.EmployeeService;

@RestController
@RequestMapping("/employee")
@CrossOrigin		// this will allow AJAX calls from differrnt port number or diff machines
public class EmployeeRESTController {

	/*
	 * private EmployeeService employeeService = new EmployeeService();
	 */
	
	@Autowired
	private EmployeeService employeeService;
	
	
	//http://localhost:8085/RESTTest/rest/employee/allEmp
	@GetMapping(value = "allEmp", produces = MediaType.APPLICATION_JSON_VALUE)
	public Collection<Employee> empList(){
		
		return employeeService.getEmployeeList();
		
	}
	
	@GetMapping(value = "getEmp/{id}", produces = {MediaType.APPLICATION_XML_VALUE,    MediaType.APPLICATION_JSON_VALUE})
	public Employee getEmployee(@PathVariable int id) {
		
		return employeeService.getEmployee(id);
		
	}
	
	@PostMapping(value = "saveEmp", 
			produces = MediaType.APPLICATION_JSON_VALUE, 
			consumes = MediaType.APPLICATION_JSON_VALUE)
	public Employee saveEmployee(@RequestBody Employee emp) {
		
		employeeService.saveEmployee(emp);
		
		return emp;
	}
	
}
