class first  extends Thread
{
private
int i;
	public void run()
	{
		for(i=1;i<=5;++i)
		{
		System.out.println("First=" +i);
		}
	}
void show()
{
System.out.println("\nDisplay First ");
}


}

class second  extends Thread
{
private
int a;
	public void run()
	{
		for(a=1;a<=5;++a)
		{
		System.out.println("Second=" +a);
		}
	}
void show1()
{
System.out.println("\nDisplay Second ");
}

void show2()
{
System.out.println("Show2 method from second class");
}


}
class MyMain
{

	public static void main(String args[])
	{
	first obj=new first();
	second obj1=new second();
	obj.start(); //activate run
	obj.show(); 
	//
	obj1.start();
	obj1.show1();
	obj1.show2();
	}
}