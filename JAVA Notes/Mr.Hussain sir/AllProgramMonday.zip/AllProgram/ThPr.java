
/*  Write a java program which will display name and priority of current thread. 
Change name of Thread to MyThread and set the priority to 2 and display 
it on screen.

Thread Methods
1. The getName() method of thread class is used to return the name of thread.
2.The getPriority() method of thread class is used to check the priority of 
the thread. When we create a thread, it has some priority assigned to it. 
Priority of thread can either be assigned by the JVM or by the 
programmer explicitly while creating the thread.
The thread's priority is in the range of 1 to 10.
3.
The setPriority() method of thread class is used to change the thread's 
priority. Every thread has a priority which is represented by the integer 
number between 1 to 10. Thread class provides 3 constant properties:
 public static int MIN_PRIORITY: It is the maximum priority of a thread.

*/
class ThPr
{
            public static void main(String a[])
            {
                        String S;
                        int p;

                        Thread t = Thread.currentThread();

                        S = t.getName();
                        System.out.println("\n Current Thread name : "+S);

                        p = t.getPriority();
                    System.out.println("\n Current thread priority : "+p);

                        t.setName("My Thread");
                        S = t.getName();
                        System.out.println("\nChanged Name : "+S);

                        t.setPriority(2);
                        p = t.getPriority();
                        System.out.println("\nChanged Priority : "+p);
            }
}