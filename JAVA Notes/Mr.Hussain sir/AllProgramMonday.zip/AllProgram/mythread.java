/* Write a multithreading program in java to display all the vowels from a given String.
*/

import java.util.*;
class Myth extends Thread
{
  String s1;
  int count;
//Parameterized constructor
  Myth(String s)
  {           
  s1=s;
  start(); //invoke run()
  System.out.println("End");
  }
         public void run()
           {
	
           System.out.println("Vowels are  ");
           for(int i=0;i<s1.length();++i)
           {
             char ch=s1.charAt(i); //s1=nice
		if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u'||ch=='A'||		ch=='E'||ch=='I'||ch=='O'||ch=='U')
		{
  		System.out.print(" "+ch);
  		count++;
 		}

 	}
System.out.println("\nTotal Vowels ="+count);
  }

}

class mythread
{ 
           public static void main(String a[]) throws Exception
            {
        Scanner obj = new Scanner(System.in);
         System.out.println("Enter a string");
         String str=obj.next(); //str=nice

         Myth v=new Myth(str);

            }
}