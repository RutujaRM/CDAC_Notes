class X extends Thread
{
	public void run()
	{
	for(int i=1;i<=5;i++)
	{
	System.out.println("I="+i);
	}
	}
void show()
{
System.out.println("Hello Friends");
}
}

class Y extends Thread
{
	public void run()
	{
	for(int j=1;j<=5;j++)
	{
	System.out.println("J="+j);
	}
	}
}
class THP
{
public static void main(String args[])
{
X threadx=new X();
Y thready=new Y();

thready.setPriority(Thread.MAX_PRIORITY);
threadx.setPriority(Thread.MIN_PRIORITY);
threadx.start();
thready.start();
}
}


