#!/bin/bash

hours=180
rate=100

income=`expr $hours \* $rate`

echo "Income = $income"

exit 0

