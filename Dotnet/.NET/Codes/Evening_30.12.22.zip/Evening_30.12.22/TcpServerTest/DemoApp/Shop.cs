using System.Xml.Linq;

class Shop
{
    private XElement root;

    private Shop(XElement root)
    {
        this.root = root;
    }

    public static Shop Open(string doc)
    {
        var items = XElement.Load(doc);
        return new Shop(items);
    }

    public string GetItemInfo(string name)
    {
        return root.Elements("item")
                .Where(i => (string)i.Attribute("key") == name)
                .Select(e => e.Value)
                .FirstOrDefault();
    }
}