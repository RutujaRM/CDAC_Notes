﻿using System.Net;
using System.Net.Sockets;

class Program
{
    static void Main(string[] args)
    {
        var shop = Shop.Open("CitiTek.xml");
        var listener = new TcpListener(IPAddress.Any, 5000);
        listener.Start();
        Service(listener, shop);
    }
    
    private static void Service(TcpListener listener, Shop shop)
    {
        for(;;)
        {
            using var client = listener.AcceptTcpClient();
            using var channel = client.GetStream();
            using var reader = new StreamReader(channel);
            using var writer = new StreamWriter(channel) { AutoFlush = true };
            client.ReceiveTimeout = 20000;
            try
            {
                writer.WriteLine("Welcome to CitiTek");
                string item = reader.ReadLine();
                string info = shop.GetItemInfo(item);
                if(info != null)
                    writer.WriteLine(info);
            }
            catch(Exception ex)
            {
                Console.WriteLine("Communication Failure: {0}", ex.Message);
            }
        }
    }   
}