using BasicWebApp.Services;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddSingleton<ICounter, CommonCounter>();
builder.Services.AddRazorPages(); //enable razor pages
var app = builder.Build();
//for each X.cshtml in Pages folder, map corresponding handler 
//to the path specified by its 'page' directive and if this
//path is not specified map it to /X with X=Index by default
app.MapRazorPages();
app.Run();
