using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Authentication;
using System.Security.Claims;

namespace DBWebApp.Pages;

using Data;

public class IndexModel : PageModel
{
    [BindProperty]
    public Customer Input { get; set; }

    public void OnGet()
    {
        Input = new Customer();
    }

    public async Task<IActionResult> OnPostAsync()
    {
        var db = new ShopDbContext();
        var customer = db.Customers.Find(Input.Id);
        if(customer?.Password == Input.Password)
        {
            var identity = new ClaimsIdentity("Cookies");
            identity.AddClaim(new Claim(ClaimTypes.Name, Input.Id));
            await HttpContext.SignInAsync(new ClaimsPrincipal(identity));
            return RedirectToPage("Detail");
        }
        ModelState.AddModelError("Login", "Invalid Customer ID or Password");
        return Page();
    }
}