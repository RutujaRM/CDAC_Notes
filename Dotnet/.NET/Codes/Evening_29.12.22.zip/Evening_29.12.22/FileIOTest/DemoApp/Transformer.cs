static class Transformer
{
    public static void Encrypt(Span<byte> data, int count)
    {
        for(int i = 0; i < count; ++i)
            data[i] = (byte)(data[i] ^ '#');
    }

    public static void Reverse(UnmanagedMemoryAccessor data, long count)
    {
        for(long i = 0, j = count - 1; i < j; ++i, --j)
        {
            byte ib = data.ReadByte(i);
            byte jb = data.ReadByte(j);
            data.Write(i, jb);
            data.Write(j, ib);
        }
    }
}
