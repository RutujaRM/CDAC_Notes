namespace Tourism;

public class Site
{
    public string Id { get; set; } = null!;

    public List<Visitor> Visitors { get; set; } = new();

    public Visitor GetVisitor(string name)
    {
        var visitor = Visitors.Find(v => v.Id == name);
        if(visitor == null)
        {
            visitor = new Visitor { Id = name };
            Visitors.Add(visitor);
        }
        return visitor;
    }
}