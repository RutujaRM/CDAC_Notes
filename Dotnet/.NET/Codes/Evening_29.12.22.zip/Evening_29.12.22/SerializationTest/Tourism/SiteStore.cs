using System.Text.Json;
using System.IO.Compression;

namespace Tourism;

public class SiteStore
{
    public bool Save(Site info)
    {
        string doc = info.Id + ".site";
        try
        {
            using var output = new DeflateStream(new FileStream(doc, FileMode.Create), CompressionMode.Compress);
            JsonSerializer.Serialize(output, info);
            return true;
        }
        catch
        {
            return false;
        }
    }

    public Site Load(string name)
    {
        string doc = name + ".site";
        try
        {
            using var input = new DeflateStream(new FileStream(doc, FileMode.Open), CompressionMode.Decompress);
            return JsonSerializer.Deserialize<Site>(input)!;
        }
        catch
        {
            return new Site { Id = name };
        }
    }
}