﻿using Tourism;

var store = new SiteStore();
var site = store.Load("CitiZoo");
if(args.Length > 0)
{
    var guest = site.GetVisitor(args[0]);
    guest.Visit();
    Console.WriteLine($"Welcome {guest.Id}, your ticket number is {guest.Ticket}");
    store.Save(site);
}
else
{
    foreach(var visitor in site.Visitors)
        Console.WriteLine($"{visitor.Id}\t{visitor.VisitCount}\t{visitor.LastVisit}");
}
