﻿if(args.Length == 0)
    Server.Run();
else
    Client.Run(args[0]);