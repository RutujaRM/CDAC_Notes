interface IStackReader<out V>
{
    V Pop();
    bool Empty();
}

interface IStackWriter<in V>
{
    void Push(V item);
}

class SimpleStack<V> : IStackReader<V>, IStackWriter<V>
{
    private Node top;

    class Node
    {
        internal V value;
        internal Node below;
    }

    public void Push(V item)
    {
        top = new Node {value = item, below = top};
    }

    public V Pop()
    {
        V item = top.value;
        top = top.below;
        return item;
    }

    public bool Empty()
    {
        return top == null;
    }

}