﻿var a = new SimpleStack<string>();
a.Push("Monday");
a.Push("Tuesday");
a.Push("Wednesday");
a.Push("Thursday");
a.Push("Friday");
for(var e = a.GetEnumerator(); e.MoveNext();)
    Console.WriteLine(e.Current.ToUpper());
Console.WriteLine("------------------");
while(!a.Empty())
    Console.WriteLine(a.Pop());
Console.WriteLine("------------------");
SimpleStack<double> b = new();
b.Push(5.31);
b.Push(6.52);
b.Push(4.13);
b.Push(7.24);
foreach(double d in b)
    Console.WriteLine("{0:0.0000}", d * d);
