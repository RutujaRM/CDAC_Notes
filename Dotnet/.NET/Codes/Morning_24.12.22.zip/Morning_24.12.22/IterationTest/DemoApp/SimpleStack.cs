using System.Collections;

class SimpleStack<V> : IEnumerable<V>
{
    private Node top;

    class Node
    {
        internal V value;
        internal Node below;
    }

    public void Push(V item)
    {
        top = new Node {value = item, below = top};
    }

    public V Pop()
    {
        V item = top.value;
        top = top.below;
        return item;
    }

    public bool Empty()
    {
        return top == null;
    }

    //To support enumeration(iteration) for its objects, a type
    //must include a public definition of GetEnumerator() method
    //whose return type must expose Current property and MoveNext()
    //method as declared in standard IEnumerator<E> interface
    public IEnumerator<V> GetEnumerator()
    {
        for(Node n = top; n != null; n = n.below)
        {
            //yield keyword is used to return multiple values
            //one-by-one from this method through an auto-generated
            //implementation of standard enumeration interface
            //specified as the return type of this method
            yield return n.value;
        }
    }

    IEnumerator IEnumerable.GetEnumerator()
    {
        return GetEnumerator();
    }

}