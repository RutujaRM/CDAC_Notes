﻿global using System.Numerics;

class Program
{
    static T Select<T>(int index, T first, T second) 
    {
        if((index % 2) == 1)
            return first;
        return second;
    }

    static T Select<T>(T first, T second) where T: IComparable<T>
    {
        if(first.CompareTo(second) > 0)
            return first;
        return second;
    }

    static T Sum<T>(T[] values) where T: IAdditionOperators<T, T, T>, new()
    {
        T total = new T();
        foreach(T value in values)
            total += value;
        return total;
    }

    static void Main(string[] args)
    {
        if(args.Length > 0)
        {
            int s = int.Parse(args[0]);
            string ss = Select(s, "Monday", "Friday");
            Console.WriteLine($"Selected string = {ss}");
            double sd = Select(s, 43.1, 56.7);
            Console.WriteLine($"Selected double = {sd}");
            //double dsd = (double)Select(s, "Monday", 56.7);
        }
        else
        {
            string ss = Select("Monday", "Friday");
            Console.WriteLine($"Selected string = {ss}");
            double sd = Select(43.1, 56.7);
            Console.WriteLine($"Selected double = {sd}");
            Interval si = Select(new Interval(5, 40), new Interval(4, 30));           
            Console.WriteLine($"Selected Interval = {si}");
        }
        double[] dv = {12.3, 23.4, 32.5, 41.7, 68.1};
        Console.WriteLine("Sum of doubles = {0}", Sum(dv));
        Interval[] iv = {new Interval(2, 30), new Interval(4, 50), new Interval(5, 40)};
        Console.WriteLine("Sum of Intervals = {0}", Sum(iv));
        
    }
}