namespace Banking;

public interface IFinable
{
    bool Withdraw(double fine);
}