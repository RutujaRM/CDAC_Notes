namespace Banking;

//a class defined with public modifier is visible from
//outside of the current assembly/project
public class InsufficientFundsException : ApplicationException {}
