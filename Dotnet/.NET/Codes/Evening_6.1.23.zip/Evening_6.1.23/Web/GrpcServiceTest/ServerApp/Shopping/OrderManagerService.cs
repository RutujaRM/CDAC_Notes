using Sales;
using Grpc.Core;

namespace ServerApp.Shopping;

public class OrderManagerService : OrderManager.OrderManagerBase
{
    //public override Task<OrderStatus> PlacOrder(OrderInput request, ServerCallContext context)
    public override async Task<OrderStatus> PlacOrder(OrderInput request, ServerCallContext context)
    {
        var reply = new OrderStatus();
        var db = new ShopDbContext();
        //var counter = db.Counters.Find("order");
        var counter = await db.Counters.FindAsync("order");
        var order = new Order 
        {
            Id = ++counter.CurrentValue + counter.SeedValue,
            OrderDate = DateTime.Today,
            CustomerId = request.CustomerCode,
            ProductNo = request.ItemCode,
            Quantity = request.ItemCount
        };
        db.Orders.Add(order);
        try
        {
            //db.SaveChanges();
            await db.SaveChangesAsync();
            reply.ConfirmationCode = order.Id;
        }
        catch(Exception ex)
        {
            Console.WriteLine(ex);
            context.Status = new Status(StatusCode.Internal, "Order Failed.");
        }
        //return Task.FromResult(reply);
        return reply;
    }

    public override async Task FetchOrders(CustomerInput request, IServerStreamWriter<CustomerOrder> responseStream, ServerCallContext context)
    {
        var db = new ShopDbContext();
        var selection = from e in db.Orders
                        where e.CustomerId == request.CustomerCode
                        select new CustomerOrder
                        {
                            ItemCode = e.ProductNo,
                            ItemCount = e.Quantity,
                            DateOfPurchase = e.OrderDate.ToString("yyyy-MM-dd")
                        };
        foreach(var item in selection)
            await responseStream.WriteAsync(item);
    }
}