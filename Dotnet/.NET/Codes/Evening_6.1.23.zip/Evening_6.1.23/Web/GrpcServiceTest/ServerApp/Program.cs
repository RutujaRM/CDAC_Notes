var builder = WebApplication.CreateBuilder(args);
builder.Services.AddGrpc(); //enable gRPC
var app = builder.Build();
app.MapGrpcService<ServerApp.Shopping.OrderManagerService>();
//Kestrel must listen on HTTP/2 endpoint (see appsettings.json)
app.Run("http://*:4000");
