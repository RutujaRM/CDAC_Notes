import grpc
from order_manager_pb2 import *
from order_manager_pb2_grpc import OrderManagerStub

id = input('Customer ID: ')
with grpc.insecure_channel('192.168.24.31:4000') as channel:
	client = OrderManagerStub(channel)
	request = CustomerInput(customer_code = id)
	reply = client.FetchOrders(request);
	total = sum(order.item_count for order in reply)
	print('Number of items purchased is', total)


