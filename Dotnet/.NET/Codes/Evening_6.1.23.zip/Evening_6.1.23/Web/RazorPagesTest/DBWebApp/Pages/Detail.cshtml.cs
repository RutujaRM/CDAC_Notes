using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;

namespace DBWebApp.Pages;

using Data;

[Authorize]
[ResponseCache(NoStore = true)]
public class DetailModel : PageModel
{
    public Customer Current { get; set; }

    public void OnGet()
    {
        var db = new ShopDbContext();
        Current = db.Customers.Find(User.Identity.Name);
        db.Entry(Current).Collection(p => p.Orders).Load();
    }

    public async Task<IActionResult> OnGetLogoutAsync()
    {
        await HttpContext.SignOutAsync();
        return RedirectToPage("Index");
    }
}