using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BasicWebApp.Pages;

public class HelloModel : PageModel
{
    public string Greeting { get; set; }

    [BindProperty]
    public string Person { get; set; }

    [BindProperty]
    public string Period { get; set; }

    public void OnGet()
    {
        Greeting = "Hello Visitor";
    }

    public void OnPost()
    {
        Greeting = $"Good {Period} {Person}";
    }
}