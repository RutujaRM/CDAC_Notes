var builder = WebApplication.CreateBuilder(args);
builder.Services.AddGrpcClient<Sales.OrderManager.OrderManagerClient>(
    options => options.Address = new Uri("http://localhost:4000"));
builder.Services.AddControllers();
builder.Services.AddSwaggerGen();
var app = builder.Build();
app.UseStaticFiles();
if(app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
app.UseCors(options => options.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod());
app.MapControllers();
app.Run();
