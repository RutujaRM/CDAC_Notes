using Sales;
using Grpc.Core;
using Microsoft.AspNetCore.Mvc;

namespace RestWebApp.Controllers;

using Resources;

[ApiController]
[Route("api/orders")]
public class OrderController : ControllerBase
{
    private OrderManager.OrderManagerClient client;

    public OrderController(OrderManager.OrderManagerClient client)
    {
        this.client = client;
    }

    [HttpGet]
    [Route("{id}")]
    public async Task<ActionResult<List<OrderResource>>> ReadOrders(string id)
    {
        try
        {
            var orders = new List<OrderResource>();
            var request = new CustomerInput { CustomerCode = id };
            using var reply = client.FetchOrders(request);
            await foreach(var order in reply.ResponseStream.ReadAllAsync())
            {
                orders.Add(new OrderResource 
                {
                    ProductNo = order.ItemCode,
                    Quantity = order.ItemCount,
                    OrderDate = order.DateOfPurchase
                });
            }
            if(orders.Count == 0)
                return NotFound();
            return orders;
        }
        catch(Exception ex)
        {
            Console.WriteLine(ex);
            return StatusCode(500);
        }
    }

    [HttpPost]
    public async Task<ActionResult<OrderResource>> CreateOrder(OrderResource resource)
    {
        try
        {
            var request = new OrderInput 
            {
                CustomerCode = resource.CustomerId,
                ItemCode = resource.ProductNo,
                ItemCount = resource.Quantity
            };
            var reply = await client.PlacOrderAsync(request);
            resource.OrderNo = reply.ConfirmationCode;
            return resource;
        }
        catch(Exception ex)
        {
            Console.WriteLine(ex);
            return StatusCode(500);
        }        
    }
}