﻿using System.Net;

string item = args[0].ToLower();
int quantity = int.Parse(args[1]);
string host = args[2];
string url = $"http://{host}:5001/shopping/{item}";
var client = new HttpClient();
try
{
    //var response = client.GetStringAsync(url);
    //var info = ItemInfo.Parse(response.Result);
    string response = await client.GetStringAsync(url);
    var info = ItemInfo.Parse(response);
    if(quantity <= info.Stock)
        Console.WriteLine("Total Payment: {0:0.00}", 1.05 * quantity * info.Price);
    else
        Console.WriteLine("Item out of stock!");
}
catch(HttpRequestException ex) when (ex.StatusCode == HttpStatusCode.NotFound)
{
    Console.WriteLine("Item not sold!");
}