readonly record struct ItemInfo(double Price, int Stock)
{
    public static ItemInfo Parse(string message)
    {
        string[] pairs = message.Split(',');
        double price = double.Parse(pairs[0].Substring(6));
        int stock = int.Parse(pairs[1].Substring(6));
        return new ItemInfo(price, stock);
    }
}