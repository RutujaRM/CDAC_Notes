﻿using System.Net.Sockets;

string item = args[0].ToLower();
int quantity = int.Parse(args[1]);
string host = args[2];
using var server = new TcpClient(host, 5000);
using var channel = server.GetStream();
using var reader = new StreamReader(channel);
using var writer = new StreamWriter(channel);
Console.WriteLine(reader.ReadLine());
writer.WriteLine(item);
writer.Flush();
string message = reader.ReadLine();
if(message != null)
{
    var info = ItemInfo.Parse(message);
    if(quantity <= info.Stock)
        Console.WriteLine("Total Payment: {0:0.00}", 1.05 * quantity * info.Price);
    else
        Console.WriteLine("Out of stock!");
}
else
{
    Console.WriteLine("Item not sold!");
}
