package com.app;

public interface ISortedLinkedList {
	public void Insert(int element);
	public int[] GetAllElements();
}
