package com.app;

public class SinglyListNode {
	public int data;
	public SinglyListNode next;

	public SinglyListNode(int element) {
		data = element;
		next = null;
	}
}
