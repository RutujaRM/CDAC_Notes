package com.app;

public interface ISortedLinkedList {

	public void Insert(int element);

	public void Delete(int element);

	public int[] GetAllElements();

}
