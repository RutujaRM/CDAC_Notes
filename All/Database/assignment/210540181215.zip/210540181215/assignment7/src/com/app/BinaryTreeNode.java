package com.app;

public class BinaryTreeNode {
	int data;
	BinaryTreeNode left;
	BinaryTreeNode right;

	public BinaryTreeNode(int element) {
		data = element;
		left = null;
		right = null;
	}
}
