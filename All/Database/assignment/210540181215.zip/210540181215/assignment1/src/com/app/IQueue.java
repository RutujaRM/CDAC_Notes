package com.app;

public interface IQueue {

	public void add(int num);

	public int delete();

	public boolean isEmpty();

	public boolean isFull();

}
