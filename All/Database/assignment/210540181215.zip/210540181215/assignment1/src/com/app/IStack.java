package com.app;

public interface IStack {

	public void push(int num);

	public int pop();

	public boolean isEmpty();

	public boolean isFull();
	
}
