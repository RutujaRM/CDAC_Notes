package com.app;

public interface ILinkedList {

	public void AddAtFront(int element);

	public void AddAtRear(int element);

	public int[] GetAllElements();
	
	public void deleteNode(int element);
}
