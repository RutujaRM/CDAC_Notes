#1 List department details in which no employee is working.
select department_name from departments d left join employees e
on e.department_id=d.department_id  where e.department_id is null;

 #2Find list of employees which are earning less then avg salary of there department
select * from employees t1 left join (select department_id,avg(salary) avg from employees group by department_id) t2 on t1.department_id=t2.department_id where t1.salary<t2.avg;

#3 Display list of employees which are earning more then the corresponding manager.
select e1.employee_id, concat(e1.first_name,'',e1.last_name) as "Emp Name" from employees e1 inner join employees mgr ON mgr.employee_id = e1.manager_id where e1.salary > mgr.salary;

#4 Display list of employees which are not managed by anyone
select * from employees where manager_id is null;

#5 Display department details where avg salary is more then 1000
select * from departments d1 where 1=(select case when avg(salary) >1000 then 1
else 0
end as status from employees e
where e.department_id=d1.department_id);

