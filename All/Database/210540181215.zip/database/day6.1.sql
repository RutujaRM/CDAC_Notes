use humanresource;
#1
select e1.last_name,e1.department_id,d1.department_name from employees e1 left join departments d1 on e1.department_id=d1.department_id;
#2
select e1.last_name,j1.job_title,e1.department_id,d1.department_name from employees e1 left join jobs j1 on e1.job_id=j1.job_id left join departments d1 on e1.department_id=d1.department_id left join locations l1 on d1.location_id=l1.location_id where l1.city='toronto';
#3
select e1.last_name,e1.employee_id,e2.last_name,e2.employee_id from employees e1 left join employees e2 on e1.manager_id=e2.employee_id;
#4
select * from employees where manager_id is null order by employee_id;
#5
SELECT e.department_id department, e.last_name employee, c.last_name colleague FROM employees e JOIN employees c ON (e.department_id = c.department_id) WHERE e.employee_id <> c.employee_id;
#6
select concat(e1.first_name,' ',e1.last_name) as Name, j1.job_title, d1.department_name, e1.salary, case when salary>20000 then 'A' when salary>15000 then 'B' when salary>10000 then 'C' when salary>5000 then 'D' else 'E' end 'Salary Grade' from employees e1 left join jobs j1 on e1.job_id=j1.job_id left join departments d1 on e1.department_id=d1.department_id;
#7
select concat(first_name,' ',last_name) as Name,hire_date from employees where hire_date>(select hire_date from employees where last_name='davies');
#8
select last_name,hire_date from employees where department_id=(select department_id from employees where last_name='zlotkey');
#9
select employee_id,last_name from employees where salary>(select avg(salary) from employees) order by salary;
#10
select employee_id, last_name from employees where department_id in (select department_id from employees where last_name like '%u%');
#11
select last_name,department_id,job_id from employees where department_id in (select department_id from departments where location_id='1700');
#12
select last_name, salary from employees where manager_id in (select employee_id from employees where last_name='king');
#13
select department_id,last_name,job_id from employees where department_id=(select department_id from departments where department_name='Executive');
#14
select employee_id,last_name,salary from employees where salary>(select avg(salary) from employees) and department_id in (select department_id from employees where last_name like '%u%');