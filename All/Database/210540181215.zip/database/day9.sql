#1
DELIMITER //
DROP function IF EXISTS dac //
create function  dac(id int)
returns int 
begin
declare ex int;
set ex:= (select (year(now())-year(hire_date))from employees where employee_id=id);
return ex;
end//
DELIMITER ;
#2
DELIMITER //
DROP function IF EXISTS dac //
create function  dac(id int)
returns varchar(100)
begin
declare res varchar(100);
set res:=(select group_concat(first_name) from employees where department_id=id);
return res;
end//
DELIMITER ;
#3
DELIMITER //
DROP function IF EXISTS dac //
drop table if exists temp//
create function  dac()
returns int
begin
	create temporary table temp(id int primary key);
	insert into temp (select empno from emp1 e where e.sal>any(select avg(sal) from emp1 d where e.DEPTNO=d.DEPTNO));
    update emp1 set inc = 0  where empno in (select id from temp);
    delete from temp;
    insert into temp (select empno from emp1 e where e.sal<any(select avg(sal) from emp1 d where e.DEPTNO=d.DEPTNO));
    update emp1 set inc = sal*0.1  where empno in (select id from temp);
return 1;
end//
DELIMITER ;
select dac();

#4
DELIMITER //
DROP function IF EXISTS dac //
create function  dac(id int)
returns int
begin
declare res varchar(100);
set res:=(select count(*) from employees where department_id=id);
return res;
end//
DELIMITER ;
