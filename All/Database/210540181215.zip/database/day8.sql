#4
DELIMITER //
create procedure dac2(in a int,in b int)
begin
select (a+b) as sum;
end//
DELIMITER ;
call dac2(4,5);

#5
DELIMITER //
create procedure dac5(in deptno int)
begin
declare max int;
declare min int;
select max(salary),min(salary) into max,min  from employees where department_id=deptno;
select max,min;
end//
DELIMITER ;

#6
DELIMITER //
DROP PROCEDURE IF EXISTS dac //
create procedure dac(in emp_id int)
begin
declare sal int;
select salary into sal from employees where employee_id=emp_id;
if(sal>2500)
	then select "LOW";
elseif(sal>=2500)
then select "medium";
elseif(sal>=500)
then select "high";
    end if;
end//

#7
create procedure dac(num int)
begin
case num
	when 1 then select 'jan';
    when 2 then select 'feb';
    when 3 then select 'march';
    when 4 then select 'april';
    when 5 then select 'may';
    when 6 then select 'jun';
    when 7 then select 'july';
    when 8 then select 'aug';
    when 9 then select 'sept';
    when 10 then select 'oct';
    when 11 then select 'nov';
    when 12 then select 'dec';
    else select 'Invalid';
end case;
end//
#8
DELIMITER //
DROP PROCEDURE IF EXISTS dac //
create procedure dac(num int)
begin
declare ename varchar(100);
declare dname varchar(100);
declare d_id  int;
declare num varchar(100);
select ename,emp.deptno,dname into emp_name, dept_no, dept_name from emp,dept where emp.deptno=dept.deptno and empno=emp_id;
select emp_id, emp_name, dept_no, dept_name;
end//
DELIMITER ;

#9
DELIMITER //
DROP PROCEDURE IF EXISTS dac //
create procedure dac()
begin
declare max int ;
select max(deptno+1) into max from dept;
insert into dept(deptno,dname) values(max,"education");
end//
DELIMITER ;

#procedure assignments
#2
DELIMITER //
DROP PROCEDURE IF EXISTS dac //
create procedure dac( id int,name varchar(20))
begin
insert into emp1 select * from employees where employee_id=id or first_name=name;
delete from employees where employee_id=id or first_name=name;
end//
DELIMITER ;
#3
DELIMITER //
DROP PROCEDURE IF EXISTS P10 //
CREATE PROCEDURE P10(empno INT, ename VARCHAR(30), job VARCHAR(20), mgr INT, hiredate DATE, INOUT sal DOUBLE(8,2), INOUT comm INT, deptno INT)
BEGIN
  IF (sal IS NULL) THEN
    SELECT MAX(e.sal) INTO sal FROM emp e WHERE e.deptno = deptno;
  END IF;

  IF (comm IS NULL) THEN
    SET comm = 200;
  END IF;

  INSERT INTO emp (EMPNO, ENAME, JOB, MGR, HIREDATE, SAL, COMM, DEPTNO)
    VALUES (empno, ename, job, mgr, hiredate, sal, comm, deptno);
END //
DELIMITER ;

SET @salary = 3500;
SET @comm = 500;
CALL P10(1000, 'Tony', 'Manager', 7369, '2021-11-02', @salary, @comm, 10);

#4
DELIMITER //
DROP PROCEDURE IF EXISTS dac //
CREATE PROCEDURE dac(tablename VARCHAR(30), columnname VARCHAR(30))
BEGIN
  SET @query = CONCAT('ALTER TABLE ', tablename, ' ADD PRIMARY KEY ( ', columnname, ' )');
  PREPARE stmt FROM @query;
  EXECUTE stmt;
  DEALLOCATE PREPARE stmt;
END //
DELIMITER ;

CALL P11('emp', 'empno');


#5
DELIMITER //
DROP PROCEDURE IF EXISTS dac //
CREATE PROCEDURE dac(p_salary_fix BOOLEAN)
BEGIN
  DECLARE CONTINUE HANDLER FOR 1050
    BEGIN
      SELECT 'Table Already Exists' as Message;
    END;

  CREATE TEMPORARY TABLE underpaid_emps (
    SELECT e.*, d.avg_sal FROM emp e 
      JOIN (
        SELECT deptno, ROUND(AVG(sal)) AS avg_sal FROM emp GROUP BY deptno
      ) d ON e.deptno = d.deptno
      WHERE e.sal < d.avg_sal
  );

  SELECT * FROM underpaid_emps;

  IF (p_salary_fix = TRUE) THEN
    UPDATE emp e, underpaid_emps ue SET e.sal = ue.avg_sal + 100 WHERE e.empno = ue.empno;
  END IF;

  SELECT * FROM emp;
END //
DELIMITER ;



#cursor
#1
drop table if exists temp;
drop procedure if exists deptwiseemp;
delimiter $
create procedure deptwiseemp()
begin
	declare dept_no int;
	declare Employees varchar(50);
	declare rowcount int;
	declare cur cursor for select deptno, GROUP_CONCAT(ename SEPARATOR ', ') from emp group by deptno;
	select count(*) into rowcount from (select distinct deptno from emp group by deptno) e;
	create temporary table temp(deptno int,Employee varchar(50));
	open cur;
		curloop:loop
			if(rowcount=0) then leave curloop;
			end if;
			fetch cur into dept_no,Employees;
			insert into temp values(dept_no,Employees);
			set rowcount=rowcount-1;
		end loop curloop;
	close cur;
	select * from temp;
	drop table temp;
end$
delimiter ;
call deptwiseemp();
#3
delimiter //
create procedure temp(in dept_no int)
begin
	declare dept_name varchar(15);
	declare Employees varchar(50);
	declare cur cursor for select dname, GROUP_CONCAT(ename SEPARATOR ', ') from emp,dept where emp.deptno=dept_no and dept.deptno=emp.deptno;
	create temporary table temp2(dept_name varchar(15),Employees varchar(50));
	open cur;
		fetch cur into dept_name,Employees;
		insert into temp2 values(dept_name,Employees);
	close cur;
	select * from temp2;
	drop table temp2;
end//
delimiter ;
call temp(30);
