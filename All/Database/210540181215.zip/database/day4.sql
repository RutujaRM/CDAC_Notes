/*4.1*/
select * from emp where sal > all(select avg(sal) from emp group by deptno);
select * from emp where length(ename)=5;
select * from emp where ename like"J%S";
select * from emp where deptno not in (10,20,40);
select * from emp where job not in ("PRESIDENT" ,"MANAGER");
select * from emp where sal<1000;
select * from emp where comm=0 or comm is null;
select * from emp where ename like "_L%";
select distinct sal from emp order by sal desc limit 0,1;	
select distinct sal from emp order by sal limit 0,1;
select deptno,count(*) from emp group by deptno having count(*)>3;
select e.ename,e.empno,d.dname,d.loc from emp e,dept d where e.deptno=d.deptno;
select dname,deptno from dept where deptno not in (select deptno from emp);
select dname,deptno from dept where deptno in (select deptno from emp);
select ename from emp a where not exists (select 1 from emp b where b.mgr = a.empno);
select ename,' belongs to ',deptno from emp;
select count(*) from emp where year(hiredate) in(1980,1981,1982);
select ename,deptno,(case deptno when 10 then 'ten' when 20 then 'twenty' when 30 then 'thirty'when 40 then 'fourty'end)from emp;
select lower(ename) as ename, concat(upper(substring(job,1,1)),lower(substring(job,2))) as job from emp;
select * from emp where to_char(hiredate,'W') = 1;
select * from emp where to_char(hiredate,'WW') = 49;
SELECT empno,ename,job,sal,LAG(sal, 1, 0) OVER (ORDER BY sal) AS sal_prev,sal - LAG(sal, 1, 0) OVER (ORDER BY sal) AS sal_diff FROM emp;
create table emp1 select * from emp where deptno=10;
create table emp2 select * from emp  where deptno=100;
select * from emp where comm=(select max(comm) from emp);
UPDATE employees SET salary= CASE department_id 
	WHEN 40 THEN salary+(salary*.25) 
	WHEN 90 THEN salary+(salary*.15)
	WHEN 110 THEN salary+(salary*.10)
	ELSE salary
	END
	WHERE department_id IN (40,50,50,60,70,80,90,110);
select * from emp where deptno in(select deptno from emp where ename = 'JAMES');
select * from emp where sal <= (select sal from emp where ename='ADAMS');
select * from emp where hiredate < (select hiredate from emp where ename='WARD');
Select ename from emp where mgr = (select empno from emp where ename='BLAKE');
select * from emp where deptno in(select deptno from emp where job= (select job from emp where ename = 'KING'));
select * from emp where empno in(select empno from emp where ename in(select ename from emp where JOB = 'PRESIDENT'));
SELECT emp.ename,emp.JOB,emp.deptno,dnames.dname FROM emp JOIN (select dname, deptno from dept ) dnames ON emp.deptno = dnames.deptno;
select empno, ename, sal from emp union all select empno, ename, sal from emp1;
/*4.2*/
select first_name as "First Name",last_name as "Last Name" from employees;
select distinct deptno from emp;
select * from employees order by first_name desc;
select first_name ,last_name,salary,round((salary*115)/100,2) as pf from employees;
select employee_id,concat(first_name,' ',last_name)as names ,salary from employees order by salary desc;
select sum(salary) from employees;
select max(salary),min(salary) from employees;
select avg(salary), count(*) from employees;
select count(*) from employees;
select count(Distinct job_id) from employees;
select upper(first_name) from employees;
select substring(first_name,1,3) from employees;
select 171*214+625;
select concat(first_name," " ,last_name,",") from employees;
select trim(first_name) from employees;
select length(concat(first_name," " ,last_name,",")) as length from employees;
SELECT first_name From employees where first_name regexp '[0-9]';
select * from employees limit 10;
select round(salary,2) as "annual salary info" from employees;