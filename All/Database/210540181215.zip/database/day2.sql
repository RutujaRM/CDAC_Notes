use demo;
create table customer
( 	customer_id int primary key,
	customer_name varchar(20) not null,
	customer_details varchar(20), 
	gender varchar(10) not null,
	email_address varchar(20) not null, 
    phone_number varchar(20) not null unique, 
    address varchar(30) not null,
	town varchar(10),
    country varchar (30)
);
create table vehicle
( 	reg_number int primary key,
	current_milege int not null,
    daily_hire_rate double not null,
    date_mot_due date not null,
    engine_size varchar(20)
);
create table booking
( 	booking_id int primary key,
	date_from date not null,
    date_to date not null,
    confirmation_letter_sent varchar(5) not null,
	payment_received varchar(5) not null,
    FOREIGN KEY(booking_id) REFERENCES customer(customer_id),
    FOREIGN KEY(booking_id) REFERENCES vehicle(reg_number)
);
create table booking_status
( 	
	booking_status_code int primary key,
    booking_status_description varchar(50),
    FOREIGN KEY(booking_status_code) REFERENCES booking(booking_id)
);
create table vehicle_category
( 	
	vehicle_status_code int primary key,
    vehicle_category_description varchar(50),
    FOREIGN KEY(vehicle_status_code) REFERENCES vehicle(reg_number)
);
create table model
( 	
	model_code int primary key,
    daily_hire_rate double,
    model_name varchar(20) not null,
    FOREIGN KEY(model_code) REFERENCES vehicle(reg_number)
);
create table manufacturer
( 	
	manufacturer_code int primary key,
    manufacturer_name varchar(20) not null,
    manufacturer_details varchar(20),
    FOREIGN KEY(manufacturer_code) REFERENCES model(model_code)
);
