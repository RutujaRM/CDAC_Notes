#1
DELETE t1 FROM test t1  
INNER JOIN test t2   
WHERE  
    t1.id < t2.id AND  
    t1.name = t2.name; 

#2
select * from emp limit n,1;

#3
select * from emp order by sal desc limit 2,1;

#4
select * from emp order by empno desc limit 1;

#5
Select * from emp where id % 2 != 0;

#6
SELECT distinct a.sal FROM(SELECT sal,RANK() over(ORDER BY sal desc) AS rk FROM emp) as a where rk=3;

#7 
create table emp1 like emp1;
insert into emp1 select * from emp;

#8
select * from emp e ,dept d where d.deptno=e.deptno;
#9
SELECT * FROM emp
UNION
SELECT * FROM emp1;

#10
SELECT '  *' FROM dual UNION SELECT ' * *' FROM dual UNION SELECT '* * *' FROM dual;

#11
select * from emp where email like '%@gmail.com';

#12
SELECT     ename,     COUNT(ename)FROM    emp GROUP BY ename HAVING COUNT(ename) > 1;
#13
select count(replace(ename,'s','S')) from emp1;
#15
Select * from emp where id % 2 = 0; 

#16
SELECT * FROM emp WHERE empno IN (SELECT empno FROM emp  WHERE sal = (SELECT MAX(sal) FROM emp WHERE sal < (SELECT MAX(sal) FROM emp)));

#17
SELECT employee_id, concat(first_name,',' ,last_name) as name FROM employees 
WHERE department_id IN  
( SELECT department_id  
FROM employees  
WHERE first_name LIKE '%T%' );

#18
select * from employees where salary > (select salary from employees where job_id="PU_MAN"); 

#20

drop procedure if exists palindrome;
delimiter //
create procedure palindrome(str varchar(10))
begin
declare str1 varchar(20);
	set str1=str;
	if str1=reverse(str)
		then
			select "palindrome";
	else
		select "not palindrome";
    end if;
end//
delimiter ; 
call palindrome("abc");

#21
drop procedure if exists digit;
delimiter //
create procedure digit(num int)
begin
declare sum int default 0;
declare r int default 0;
	while num<>0 do
		set r=mod(num,10);
		set sum=sum+r;
		set num=num/10;
    END while;
    select sum;
end//
delimiter ; 
call digit(14);


#22
