#procedure
#1
drop procedure if exists USER_QUERY_EMP;
delimiter //
create procedure USER_QUERY_EMP(IN empid int,out myjob varchar(20),out salary int)
begin
	select job,sal into myjob,salary from emp where empno=empid; 
end //
delimiter ;
call USER_QUERY_EMP(7369,@x,@y);
select @x,@y;

#2
drop function if exists USER_ANNUAL_COMP;
delimiter //
create function USER_ANNUAL_COMP( eno int,salary int,commision int)
returns int
begin
        return (ifnull(salary,0)+ifnull(commision,0)) * 12;
end //
delimiter ;
select USER_ANNUAL_COMP(7369,800,null);
#2.1
drop function if exists USER_ANNUAL_COMP;
delimiter //
create function USER_ANNUAL_COMP( eno int)
returns int
begin
declare mysal int;
declare mycomm int;
		select sal,comm into mysal,mycomm from emp where empno=eno;
        return (ifnull(mysal,0)+ifnull(mycomm,0)) * 12;
end //
delimiter ;
select USER_ANNUAL_COMP(7369);


#3
drop function if exists USER_VALID_DEPTNO;
delimiter //
create function USER_VALID_DEPTNO( dno int)
returns varchar(20)
begin
declare res int;
        
       if (dno in(select deptno from emp))
			then 
				return "true";
		else
			return  "false";
		end if;
end //
delimiter ;
select USER_VALID_DEPTNO(100);

drop procedure if exists SHOW_STRENGTH;
delimiter //
create procedure SHOW_STRENGTH(dno int)
begin
	 if  USER_VALID_DEPTNO(dno) = "true"
     then 
		select count(*) from emp where deptno =dno;
	else
		select "invalid deptno";
	end if;
end//
delimiter ;
call SHOW_STRENGTH(100);

#4

delimiter $
drop procedure if exists ADD_EMPLOYEE$
create procedure ADD_EMPLOYEE(in ename varchar(10),in job_name varchar(20),in mgr_id int,in hiredate date,in salary float,in commission float,in deptno int)
begin
	if(valid_job(job_name) and valid_mgr(mgr_id) and valid_date(hiredate) and valid_sal(salary) and valid_comm(commission,job_name) and valid_deptno(deptno))
	then insert into emp values(default,ename,job_name,mgr_id,hiredate,salary,commission,deptno,null);
	select '1 row inserted' as Result;
	else SIGNAL sqlstate '45000' set message_text = 'Error inserting new Employee due to incorrect details !';
	end if;
end$
delimiter ;
call ADD_EMPLOYEE('bwooii','salesman',7566,'2020-09-25',80000,null,40);

#-----------JOB Validation-----------

delimiter $
drop function if exists valid_job$
create function valid_job(job_name varchar(20)) returns boolean
begin
 return job_name in ('CLERK','ANALYST','SALESMAN');
end$
delimiter ;

#-----------MGR Validation-----------

delimiter $
drop function if exists valid_mgr$
create function valid_mgr(mgr_id int) returns boolean
begin
 return mgr_id in (select empno from emp);
end$
delimiter ;

#-----------HireDate Validation-----------

delimiter $
drop function if exists valid_date$
create function valid_date(hire_date date) returns boolean
begin
 return hire_date <curdate();
end$
delimiter ;

#-----------Salary Validation-----------

delimiter $
drop function if exists valid_sal$
create function valid_sal(salary float) returns boolean
begin
 return salary>800;
end$
delimiter ;

#-----------Commission Validation-----------

delimiter $
drop function if exists valid_comm$
create function valid_comm(commission float,job_name varchar(20)) returns boolean
begin
 if (job_name='salesman' and commission is not null)
 or 
 (job_name!='salesman' and commission is null) then return true;
 else return false;
 end if;
end$
delimiter ;

#-----------Department Validation-----------

delimiter $
drop function if exists valid_deptno$
create function valid_deptno(p_dno int) returns boolean
begin
	return p_dno in (select deptno from dept);
end$
delimiter ;

#5
delimiter //
drop function if exists FIND_SAL_GRADE//
create function FIND_SAL_GRADE(salary int) returns varchar(5)
begin
if (select grade from salgrade where salary between losal and hisal) is null
	then signal sqlstate '45000';
else
	return (select grade from salgrade where salary between losal and hisal);
end if;
end//
delimiter ;
select FIND_SAL_GRADE(2000) as Grade;
delimiter //
drop procedure if exists CALL_FIND_SAL_GRADE//
create procedure CALL_FIND_SAL_GRADE()
begin
declare continue handler for sqlstate '45000' resignal set message_text = 'Salary not in specified range !';
select empno,ename,sal,FIND_SAL_GRADE(sal) from emp;
end//
delimiter ;






#triggers
#1
use scottschema;
delimiter //
drop procedure if exists SECURE_DML//
create procedure SECURE_DML()
begin 
	if month(now())=12
		then
			update  emp set comm= 100 where empno=7698;
	end if;
end//
delimiter ;

delimiter //
drop trigger if exists TR_CHECK_DEPT//
create trigger TR_CHECK_DEPT 
	before
		update on emp for each row 
begin
        call SECURE_DML();
end//
delimiter ;

#2
delimiter //
drop trigger if exists TR_CASCADE_CHANGE//
create trigger TR_CASCADE_CHANGE
	after
		update on dept for each row
begin
	update emp set deptno=new.deptno where deptno=new.deptno;
end//
delimiter ;
update dept set deptno=100 where deptno=10;

#3
delimiter //
drop trigger if exists TR_CHECK_COMM//
create trigger TR_CHECK_COMM
	before
		insert on emp for each row
begin
	if(new.job='salesman')
		then
			set new.comm=100;
	else
		set new.comm=null;
	end if;
end//
delimiter ;
insert into emp values(2,'uday','salesman',7566,'2000-09-25',8000,null,40);

#4
delimiter //
drop trigger if exists TR_VALIDATE_SAL//
create trigger TR_VALIDATE_SAL
	before
		update on emp for each row
begin
	if new.sal not between(select min(losal) from salgrade) and (select max(hisal) from salgrade)
		then
			set new.sal=old.sal;
	end if;
end//
delimiter ;

#5
delimiter //
drop trigger if exists TR_CHECK_GRADE//
create trigger TR_CHECK_GRADE after update on emp for each row
begin
if FIND_SAL_GRADE(old.sal)!=FIND_SAL_GRADE(new.sal)
then insert into salaryLog values(new.empno,FIND_SAL_GRADE(new.sal),old.sal,new.sal);
end if;
end//
delimiter ;