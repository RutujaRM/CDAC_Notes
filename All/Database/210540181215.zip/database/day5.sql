/*5.1*/
select * from emp where hiredate<(select hiredate from emp where ename="SCOTT");
select * from emp where deptno in (select deptno from emp group by deptno having count(deptno)>3);
select * from emp where sal in (select min(sal) from emp group by deptno);
SELECT ename, sal, dept.deptno, dname, loc FROM emp, dept WHERE emp.deptno = dept.deptno;select * from emp where sal in (select max(sal) from emp group by deptno);
select dname from dept where deptno not in(select deptno from emp);
select dname from dept where deptno in(select deptno from emp where deptno group by deptno having count(deptno)>0);
select * from emp where job!="MANAGER";
select * from emp where deptno in(select deptno from  emp where ename="JAMES");
select * from emp where sal <=(select sal from  emp where ename="JAMES");
select empno,ename,b.deptno,dname,grade from emp a,dept b, salgrade c where a.deptno = b.deptno and sal between losal and hisal;
select * from emp where deptno in(select deptno from dept where loc="dallas");
/*5.2*/
select e.first_name,e.last_name,d.department_name,d.department_id from employees e join departments d  on e.department_id=d.department_id;
SELECT e.first_name,e.last_name,d.department_name, l.city, l.state_province FROM employees e
      JOIN departments d  
        ON e.department_id = d.department_id  
          JOIN locations l
           ON d.location_id = l.location_id;
SELECT e.first_name, e.last_name, e.salary, j.grade_level
 FROM employees e 
   JOIN job_grades j
     ON e.salary BETWEEN j.lowest_sal AND j.highest_sal;
select e.first_name,e.last_name ,d.department_name,d.department_name from employees e inner join departments d on d.department_id=e.department_id where d.department_id in(80,90);
SELECT e.first_name,e.last_name,
	d.department_name, l.city, l.state_province
	FROM employees e 
	JOIN departments d  
	ON e.department_id = d.department_id 
	JOIN locations l 
	ON d.location_id = l.location_id 
	WHERE e.first_name LIKE  '%z%';
select d.department_id,d.department_name,e.first_name,e.last_name from employees e right outer join departments d on e.department_id = d.department_id;
select first_name ,last_name, salary  from employees where salary <all(select salary from employees where employee_id=182);
select m.first_name as employee ,e.first_name as manager from employees e inner join employees m on e.employee_id=m.manager_id;
select d.department_name,l.city ,l.state_province from departments d inner join locations l  on d.location_id=l.location_id ;
select e.first_name,e.last_name,e.department_id from employees e left join departments d on d.department_id=e.department_id;
select e.first_name,m.last_name from employees e left outer join employees m on e.manager_id=m.employee_id;
select first_name,last_name,department_id from employees where department_id in (select department_id from employees where last_name="Taylor");
SELECT job_title, department_name, concat(first_name,last_name) AS Employee_name, start_date FROM job_history JOIN jobs USING (job_id) 
JOIN departments USING (department_id)JOIN  employees USING (employee_id)WHERE start_date>='1993-01-01' AND start_date<='1997-08-31';
SELECT job_title,concat( first_name,last_name) AS Employee_name, max_salary-salary AS salary_difference  FROM employees NATURAL JOIN jobs;
SELECT department_name, AVG(salary), COUNT(commission_pct) 	FROM departments JOIN employees USING (department_id) GROUP BY department_name;
SELECT job_title, concat(first_name,last_name) AS Employee_name,max_salary-salary AS salary_difference	FROM employees 	NATURAL JOIN jobs 
WHERE department_id  = 80;
SELECT country_name,city, department_name 	FROM countries JOIN locations USING (country_id) JOIN departments USING (location_id);
select d.department_name,concat(e.first_name,e.last_name) from departments d inner join employees e on d.manager_id=e.employee_id;
select j.* from job_history j inner join employees e on e.employee_id=j.employee_id where salary>=12000;
SELECT country_name,city, COUNT(department_id)FROM countries JOIN locations USING (country_id) JOIN departments USING (location_id) 
WHERE department_id IN (SELECT department_id  FROM employees  GROUP BY department_id  HAVING COUNT(department_id)>=2) GROUP BY country_name,city;
SELECT department_name, concat(first_name,last_name )AS name_of_manager, city FROM departments D JOIN employees E ON (D.manager_id=E.employee_id) JOIN locations L USING (location_id);
SELECT employee_id, job_title, end_date-start_date DAYS FROM job_history NATURAL JOIN jobs WHERE department_id=80;
SELECT concat(first_name ,last_name) AS Employee_name, salary FROM employees JOIN departments USING (department_id) JOIN  locations USING (location_id) 
WHERE  city = 'LONDON';
SELECT CONCAT(e.first_name,  e.last_name) AS Employee_name, j.job_title,h.* FROM employees e JOIN (SELECT MAX(start_date),MAX(end_date),
employee_id FROM job_history  GROUP BY employee_id) h ON e.employee_id=h.employee_id JOIN jobs j ON j.job_id=e.job_id WHERE e.commission_pct = 0;
SELECT d.department_name,e.* FROM departments d JOIN (SELECT count(employee_id), department_id FROM employees GROUP BY department_id) e USING (department_id);
SELECT concat(first_name,last_name) AS Employee_name, employee_id, country_name FROM employees JOIN departments USING(department_id) 
JOIN locations USING( location_id) JOIN countries USING ( country_id);