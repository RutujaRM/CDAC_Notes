
/*Q1. Create a view to fetch the employees data 
EmployeeId, EmployeeName, EmployeeSalary, EmployeeManager, EmployeeDepartment
*/
create view vw as select e.employee_id,concat(e.first_name,'',e.last_name),e.salary,m.first_name,d.department_name from employees e
inner join departments d on e.department_id=d.department_id
inner join employees m on e.manager_id=m.employee_id;
select * from vw;
/*Q2. Create a view to fetch all the employees data working on jobs with 
minimum salary > 2000 and maximum salary < 5000;*/
drop view Salview;
create view Salview1 as select concat(e.first_name,' ',e.last_name) as "Employee Name" ,e.salary as "Emp_Salary" from employees e where salary between 2000 and 5000;
select * from Salview1;
/*Q3. Create a view to fetch employee data 
EMPLOYEEID,EMPLOYEENAME,EMPLOYEEDEPARTMENT,EMPLOYEESALARY,EMPLOYEECOUNTRY,EMPLOYEELOCATION,
EMPLOYEEREGION.*/
create view employee_details_view as
select e.employee_id,concat(e.first_name,' ',e.last_name) as "Employee Name",d.department_name as "Employee Department",e.salary as "Emp Salary" ,l.city as "Emp City"
from Employees e
  inner join departments d on e.department_id=d.department_id
  inner join locations l on d.location_id=l.location_id
  order by e.employee_id;
  select * from employee_details_view;
/*Q3. CREATE A VIEW FOR Q3 AND DISPLAY ONLY THOSE EMPLOYEES WHOSE DEPARTMENTID = 30 AND SALARY < 5000;*/
  create view Dept30 as select * from employees where department_id=30 and salary<5000;
  select * from Dept30;
  
  /*
  Q4. CREATE A VIEW TO FETCH ALL EMPLOYEES DATA WITH THERE APPRAISED SALARY FOR THE CURRENT YEAR.

EG : CURRENT SALARY = 3000
COMM : 300
APPRAISED SALARY RULE : 
		PEOPLE GETTING SALARY 2000 - 10000 :: 10%
		PEOPLE GETTING SALARY 10001 -15000 :: 8%
		PEOPLE GETTING SALARY 15000 - 20000 :: 6%
		PEOPLE GETTING SALARY > 20000 :: 5%
	
  
  */
  create view EmpCom as 
  select e.first_name,e.salary,
  case
  when e.salary>=2000 and e.salary<=10000 then e.salary*0.10
  when e.salary>=10001 and e.salary<15000 then e.salary*0.08
  when e.salary>=1500 and e.salary<20000 then e.salary*0.06
  when e.salary>=2000 then e.salary*0.05
  end 'commission' from Employees e;
  select * from EmpCom;
  /*
  Q5. CREATE A VIEW ON THE EMPLOYEES TABLE WITH EMPNO , EMPNAME, EMPSALARY

	1. UPDATE THE SALARY OF EMPLOYEE ID = 105;
	2. DELETE THE ROW OF THE EMPLOYEE ID = 106;
	3. UPDATE THE EMPLOYEE DEPARTMET ID OF THE EMPLOYEEID = 108
	OBSERVE THE PARENT TABLE EMPLOYEES
    
    OBSERVATION:
    "Changes in View are Getting Reflected in 
*/
    create view simpleview as select e.employee_id,concat(e.first_name,' ',e.last_name) as "Name",e.salary
    from employees e;
    update simpleview set salary=8000 where employee_id=105;
    select * from simpleview;
    select * from employees limit 6;
    
    
    